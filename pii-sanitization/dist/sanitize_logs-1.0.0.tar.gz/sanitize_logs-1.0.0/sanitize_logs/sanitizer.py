import re

def sanitize_text(text: str) -> str:
    """
    Mask PII, confidential, and secret data in text using descriptive placeholders.
    Order of rules matters: more specific first, generic later.
    """

    rules = [
        # Names first
        (r'name="[^"]+"', 'name="[FULL NAME]"'),  # Mask name=...
        (r"\b(?:Mr|Ms|Mrs|Dr)\.?\s+[A-Z][a-z]+\s+[A-Z][a-z]+\b", "[FULL NAME]"),  # Standalone names

        # Financial identifiers
        (r"\b\d{12,16}\b", "[CARD NUMBER]"),           # Bank/credit/debit cards
        (r"\bTX\d+\b", "[TRANSACTION ID]"),            # Transaction IDs
        (r"\b\d{6,20}\b", "[ACCOUNT NUMBER]"),         # Account numbers

        # Personal identifiers
        (r"\b\d{12}\b", "[IC NUMBER]"),                # NRIC / MyKad
        (r"\b\d{8,11}\b", "[PHONE NUMBER]"),          # Phone numbers
        (r"\b([A-Za-z])\d{7}\b", "[PASSPORT NUMBER]"),# Passport
        (r"\bD\d{9,12}\b", "[DRIVER LICENSE]"),       # Driving license
        (r"\b[A-Z]{2}\d{6,8}\b", "[OTHER ID]"),       # Other IDs

        # Contact info
        (r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}", "[EMAIL]"),  # Emails
        (r"\b\d{5,10}\b", "[ZIP CODE]"),               # Postal/ZIP code
        (r"\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b", "[IP ADDRESS]"),  # IP addresses

        # Dates
        (r"\b\d{2}/\d{2}/\d{4}\b", "[DATE]"),         # DD/MM/YYYY
        (r"\b\d{4}-\d{2}-\d{2}\b", "[DATE]"),         # YYYY-MM-DD
        (r'\bdob="\d{2}/\d{2}/\d{4}"', 'dob="[DATE]"'),

        # Secrets / tokens
        (r'\b(password|passwd|pwd|secret|token|api_key)\b\s*=\s*"[^"]+"', '[SECRET]'),
        (r"-----BEGIN (?:PRIVATE|RSA|EC) KEY-----[\s\S]+?-----END (?:PRIVATE|RSA|EC) KEY-----", "[PRIVATE KEY]"),
        (r"\b[0-9a-fA-F]{32,64}\b", "[HASH]"),        # Hashes / tokens

        # OTP / PIN
        (r'otp="\d{4,6}"', 'otp="[PIN/OTP]"'),
        (r'pin="\d{4,6}"', 'pin="[PIN/OTP]"'),
    ]

    masked = text
    for pattern, replacement in rules:
        masked = re.sub(pattern, replacement, masked, flags=re.IGNORECASE)

    return masked